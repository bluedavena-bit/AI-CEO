import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// Mobile-first dev server: exposes on LAN so you can test on a real phone
export default defineConfig({
  plugins: [react()],
  server: {
    host: true,
    port: 5173
  }
})
