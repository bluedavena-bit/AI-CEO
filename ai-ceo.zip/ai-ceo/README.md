# AI CEO

A personal operating system for building wealth, improving credit, growing a
business, and hitting goals — with one AI that shares context across all of
it. This is the **Goals pillar MVP**: the wedge that proves the core loop
(goal → AI-generated plan → daily actions → check-ins → adjusted plan)
before Wealth, Credit, and Business plug into the same schema.

## Why this stack

- **React + Vite** — fast dev loop, and Vite's build output is trivially
  deployable to Vercel/Netlify/Cloudflare Pages for zero-config scaling.
- **Supabase** — Postgres gives real relational integrity between users,
  goals, plans, and actions (not a NoSQL document pile), plus Auth and
  row-level security out of the box, so a solo founder isn't hand-rolling a
  permissions system.
- **Edge Functions for OpenAI + Stripe** — API keys never touch the client.
  This is the first thing a security-conscious investor or user will check,
  and it's also just correct engineering.
- **Tailwind** — a constrained design-token system (see `tailwind.config.js`)
  keeps every screen visually consistent without hand-tuning CSS per page,
  which is how you get an Apple/Notion/Stripe-grade feel at speed.

## Local setup

```bash
npm install
cp .env.example .env   # fill in your Supabase project URL + anon key
npm run dev
```

## Supabase setup

1. Create a project at supabase.com.
2. Run `supabase/schema.sql` in the SQL editor (or via the CLI).
3. Deploy the edge functions:
   ```bash
   supabase functions deploy generate-plan
   supabase functions deploy create-checkout-session
   supabase functions deploy stripe-webhook --no-verify-jwt
   ```
4. Set function secrets:
   ```bash
   supabase secrets set OPENAI_API_KEY=sk-...
   supabase secrets set STRIPE_SECRET_KEY=sk_live_...
   supabase secrets set STRIPE_WEBHOOK_SECRET=whsec_...
   ```
5. In the Stripe dashboard, point a webhook at your deployed
   `stripe-webhook` function URL, listening for
   `customer.subscription.created/updated/deleted`.

## Why the schema is shaped this way

`goals`, `goal_plans`, and `actions` are generic enough that a Wealth goal
("grow net worth to $100k") and a Credit goal ("raise score to 750") live in
the exact same tables as a Personal goal ("run a 10k"). That's deliberate —
it's what lets the other three pillars become *extensions* of this schema
later instead of separate apps, and it's what makes the "shared AI context
engine" possible: one query across `goals` per user already spans every
pillar.

## What's next (not built yet — by design, to ship the wedge first)

- Wealth pillar: net worth tracking, needs a `accounts` table + Plaid.
- Credit pillar: needs a credit bureau API integration.
- Business pillar: extends `goals.category` + adds business-specific metrics.
- Push notifications for daily check-in reminders.
- Pricing page + `create-checkout-session` wiring into a Billing screen.
