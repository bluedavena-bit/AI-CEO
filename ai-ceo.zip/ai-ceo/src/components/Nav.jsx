import { useAuth } from '../context/AuthContext'

export default function Nav() {
  const { signOut } = useAuth()

  return (
    <header className="sticky top-0 z-10 bg-canvas/90 backdrop-blur border-b border-stone-300">
      <div className="max-w-lg mx-auto px-5 py-4 flex items-center justify-between">
        <span className="font-display text-lg font-medium">AI CEO</span>
        <button
          onClick={signOut}
          className="text-sm text-stone-600 hover:text-ink transition-colors"
        >
          Sign out
        </button>
      </div>
    </header>
  )
}
