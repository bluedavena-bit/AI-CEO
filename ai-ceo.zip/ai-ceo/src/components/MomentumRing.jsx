// The one bold visual move in the whole app (per frontend-design principles:
// spend your boldness in one place). A goal's ring fills from indigo toward
// ember as its completion streak builds — cool intention warming into
// earned momentum. Everything else in the UI stays quiet around this.

export default function MomentumRing({ progress = 0, streak = 0, size = 64 }) {
  const stroke = 5
  const radius = (size - stroke) / 2
  const circumference = 2 * Math.PI * radius
  const offset = circumference * (1 - Math.min(progress, 1))

  // Interpolate stroke color: 0% = indigo, 100% = ember
  const warm = Math.min(progress, 1)
  const color = warm > 0.5 ? '#E8590C' : '#4F3CC9'

  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="#E5E2DA"
          strokeWidth={stroke}
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          style={{ transition: 'stroke-dashoffset 0.6s ease, stroke 0.6s ease' }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="font-mono text-xs font-medium text-ink">{Math.round(progress * 100)}%</span>
      </div>
    </div>
  )
}
