import { useNavigate } from 'react-router-dom'
import MomentumRing from './MomentumRing'

export default function GoalCard({ goal }) {
  const navigate = useNavigate()
  const progress = goal.completed_actions / Math.max(goal.total_actions, 1)

  return (
    <button
      onClick={() => navigate(`/goals/${goal.id}`)}
      className="card w-full flex items-center gap-4 p-4 text-left hover:border-indigo-400 transition-colors"
    >
      <MomentumRing progress={progress} streak={goal.streak} />
      <div className="flex-1 min-w-0">
        <p className="font-display text-base font-medium text-ink truncate">{goal.title}</p>
        <p className="text-sm text-stone-600 mt-0.5">{goal.category}</p>
      </div>
      {goal.streak > 0 && (
        <div className="flex flex-col items-end shrink-0">
          <span className="font-mono text-sm font-medium text-ember-600">{goal.streak}</span>
          <span className="text-[11px] text-stone-600">day streak</span>
        </div>
      )}
    </button>
  )
}
