import { useState } from 'react'
import { useAuth } from '../context/AuthContext'

export default function Login() {
  const { signInWithEmail } = useAuth()
  const [email, setEmail] = useState('')
  const [sent, setSent] = useState(false)
  const [error, setError] = useState(null)

  async function handleSubmit(e) {
    e.preventDefault()
    setError(null)
    const { error } = await signInWithEmail(email)
    if (error) setError(error.message)
    else setSent(true)
  }

  return (
    <div className="min-h-screen flex flex-col justify-center px-6 max-w-sm mx-auto">
      <h1 className="font-display text-3xl font-medium leading-tight mb-2">
        Run your life like a company.
      </h1>
      <p className="text-stone-600 mb-8">
        One AI, every goal, a plan for tomorrow.
      </p>

      {sent ? (
        <div className="card p-4">
          <p className="text-sm">
            Check <span className="font-medium">{email}</span> for a sign-in link.
          </p>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-3">
          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@email.com"
            className="w-full px-4 py-3 rounded-xl border border-stone-300 bg-white focus:border-indigo-600 outline-none text-sm"
          />
          <button
            type="submit"
            className="w-full bg-indigo-600 text-white py-3 rounded-xl font-medium text-sm hover:bg-indigo-700 transition-colors"
          >
            Continue with email
          </button>
          {error && <p className="text-sm text-red-600">{error}</p>}
        </form>
      )}
    </div>
  )
}
