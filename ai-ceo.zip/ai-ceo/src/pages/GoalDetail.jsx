import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { supabase } from '../lib/supabaseClient'
import Nav from '../components/Nav'
import MomentumRing from '../components/MomentumRing'

export default function GoalDetail() {
  const { id } = useParams()
  const [goal, setGoal] = useState(null)
  const [actions, setActions] = useState([])
  const [reflection, setReflection] = useState('')

  useEffect(() => {
    async function load() {
      const { data: g } = await supabase.from('goals').select('*').eq('id', id).single()
      const { data: a } = await supabase
        .from('actions')
        .select('*')
        .eq('goal_id', id)
        .order('due_date', { ascending: true })
      setGoal(g)
      setActions(a ?? [])
    }
    load()
  }, [id])

  async function completeAction(actionId) {
    const { data } = await supabase
      .from('actions')
      .update({ completed_at: new Date().toISOString() })
      .eq('id', actionId)
      .select()
      .single()
    setActions((prev) => prev.map((a) => (a.id === actionId ? data : a)))
  }

  if (!goal) return null

  const completed = actions.filter((a) => a.completed_at).length
  const progress = completed / Math.max(actions.length, 1)

  return (
    <div className="min-h-screen pb-24">
      <Nav />
      <div className="max-w-lg mx-auto px-5 py-6">
        <div className="flex items-center gap-4 mb-8">
          <MomentumRing progress={progress} size={72} />
          <div>
            <h1 className="font-display text-xl font-medium">{goal.title}</h1>
            <p className="text-sm text-stone-600">{goal.category}</p>
          </div>
        </div>

        <h2 className="text-sm font-medium text-stone-600 mb-3">Your plan</h2>
        <div className="space-y-2 mb-8">
          {actions.map((action) => (
            <div key={action.id} className="card p-4 flex items-center gap-3">
              <button
                onClick={() => !action.completed_at && completeAction(action.id)}
                className={`w-5 h-5 rounded-full border-2 shrink-0 transition-colors ${
                  action.completed_at
                    ? 'bg-sage-600 border-sage-600'
                    : 'border-stone-300'
                }`}
                aria-label={action.completed_at ? 'Completed' : 'Mark complete'}
              />
              <span
                className={`text-sm ${action.completed_at ? 'text-stone-600 line-through' : 'text-ink'}`}
              >
                {action.description}
              </span>
            </div>
          ))}
          {actions.length === 0 && (
            <p className="text-sm text-stone-600">Your plan is still generating — check back shortly.</p>
          )}
        </div>

        <h2 className="text-sm font-medium text-stone-600 mb-3">Daily check-in</h2>
        <div className="card p-4">
          <textarea
            value={reflection}
            onChange={(e) => setReflection(e.target.value)}
            placeholder="How did today go?"
            rows={3}
            className="w-full text-sm outline-none resize-none placeholder:text-stone-600"
          />
          <button className="mt-2 bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-indigo-700 transition-colors">
            Log check-in
          </button>
        </div>
      </div>
    </div>
  )
}
