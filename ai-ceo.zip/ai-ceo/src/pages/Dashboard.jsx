import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../lib/supabaseClient'
import { useAuth } from '../context/AuthContext'
import Nav from '../components/Nav'
import GoalCard from '../components/GoalCard'

export default function Dashboard() {
  const { user } = useAuth()
  const [goals, setGoals] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function load() {
      // goals_with_progress is a view — see supabase/schema.sql — that
      // pre-computes completed/total actions and current streak per goal,
      // so the dashboard is a single fast query instead of N+1 lookups.
      const { data } = await supabase
        .from('goals_with_progress')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
      setGoals(data ?? [])
      setLoading(false)
    }
    if (user) load()
  }, [user])

  return (
    <div className="min-h-screen pb-24">
      <Nav />
      <div className="max-w-lg mx-auto px-5 py-6">
        <h1 className="font-display text-2xl font-medium mb-6">Your goals</h1>

        {loading && <p className="text-sm text-stone-600">Loading…</p>}

        {!loading && goals.length === 0 && (
          <div className="card p-6 text-center">
            <p className="text-sm text-stone-600 mb-4">
              No goals yet. Your first one takes two minutes to set up.
            </p>
            <Link
              to="/onboarding"
              className="inline-block bg-indigo-600 text-white px-5 py-2.5 rounded-xl text-sm font-medium hover:bg-indigo-700 transition-colors"
            >
              Create your first goal
            </Link>
          </div>
        )}

        <div className="space-y-3">
          {goals.map((goal) => (
            <GoalCard key={goal.id} goal={goal} />
          ))}
        </div>

        {goals.length > 0 && (
          <Link
            to="/onboarding"
            className="mt-4 block text-center border border-dashed border-stone-300 rounded-card py-3 text-sm text-stone-600 hover:border-indigo-400 hover:text-indigo-600 transition-colors"
          >
            + Add another goal
          </Link>
        )}
      </div>
    </div>
  )
}
