import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabaseClient'
import { generatePlan } from '../lib/api'
import { useAuth } from '../context/AuthContext'

const CATEGORIES = ['Wealth', 'Credit', 'Business', 'Health', 'Career', 'Personal']

export default function Onboarding() {
  const { user } = useAuth()
  const navigate = useNavigate()
  const [title, setTitle] = useState('')
  const [category, setCategory] = useState(CATEGORIES[0])
  const [targetDate, setTargetDate] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  async function handleSubmit(e) {
    e.preventDefault()
    setLoading(true)
    setError(null)
    try {
      const { data: goal, error: insertError } = await supabase
        .from('goals')
        .insert({ user_id: user.id, title, category, target_date: targetDate || null })
        .select()
        .single()
      if (insertError) throw insertError

      // AI breaks the goal into a first plan — this is the moment the
      // product proves it's not just a to-do list.
      await generatePlan({ goalId: goal.id, title, category, targetDate })

      navigate(`/goals/${goal.id}`)
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen px-6 py-10 max-w-sm mx-auto">
      <h1 className="font-display text-2xl font-medium mb-1">What are you working toward?</h1>
      <p className="text-stone-600 text-sm mb-8">
        AI CEO will turn this into a plan and daily actions.
      </p>

      <form onSubmit={handleSubmit} className="space-y-5">
        <div>
          <label className="text-sm font-medium block mb-1.5">Goal</label>
          <input
            required
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Pay off $8,000 in credit card debt"
            className="w-full px-4 py-3 rounded-xl border border-stone-300 bg-white focus:border-indigo-600 outline-none text-sm"
          />
        </div>

        <div>
          <label className="text-sm font-medium block mb-1.5">Category</label>
          <div className="flex flex-wrap gap-2">
            {CATEGORIES.map((c) => (
              <button
                type="button"
                key={c}
                onClick={() => setCategory(c)}
                className={`px-3 py-1.5 rounded-full text-sm border transition-colors ${
                  category === c
                    ? 'bg-indigo-600 border-indigo-600 text-white'
                    : 'border-stone-300 text-stone-600'
                }`}
              >
                {c}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="text-sm font-medium block mb-1.5">Target date (optional)</label>
          <input
            type="date"
            value={targetDate}
            onChange={(e) => setTargetDate(e.target.value)}
            className="w-full px-4 py-3 rounded-xl border border-stone-300 bg-white focus:border-indigo-600 outline-none text-sm"
          />
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full bg-indigo-600 text-white py-3 rounded-xl font-medium text-sm hover:bg-indigo-700 transition-colors disabled:opacity-50"
        >
          {loading ? 'Building your plan…' : 'Create my plan'}
        </button>
        {error && <p className="text-sm text-red-600">{error}</p>}
      </form>
    </div>
  )
}
