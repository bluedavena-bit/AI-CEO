/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        canvas: '#FAFAF8',
        ink: '#16171C',
        indigo: {
          DEFAULT: '#4F3CC9',
          50: '#EFECFB',
          100: '#DCD5F7',
          400: '#7E6DDB',
          600: '#4F3CC9',
          700: '#3C2E9E'
        },
        ember: {
          DEFAULT: '#E8590C',
          50: '#FDEEE4',
          100: '#FBD9C1',
          400: '#F0803F',
          600: '#E8590C',
          700: '#B84509'
        },
        stone: {
          DEFAULT: '#E5E2DA',
          50: '#FAFAF8',
          100: '#F2F0EA',
          300: '#E5E2DA',
          600: '#8C887C',
          900: '#3A382F'
        },
        sage: {
          DEFAULT: '#4C7A5D',
          100: '#DCEAE0',
          600: '#4C7A5D'
        }
      },
      fontFamily: {
        display: ['"Fraunces"', 'serif'],
        body: ['"Inter"', 'sans-serif'],
        mono: ['"IBM Plex Mono"', 'monospace']
      },
      borderRadius: {
        card: '20px'
      }
    }
  },
  plugins: []
}
