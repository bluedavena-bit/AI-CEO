// Supabase Edge Function (Deno). Deploy with:
//   supabase functions deploy generate-plan
// Requires OPENAI_API_KEY set as a function secret — never in client code.

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.4'

const OPENAI_API_KEY = Deno.env.get('OPENAI_API_KEY')!
const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!

Deno.serve(async (req) => {
  try {
    const { goalId, title, category, targetDate } = await req.json()

    const authHeader = req.headers.get('Authorization')!
    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
      global: { headers: { Authorization: authHeader } }
    })

    const prompt = `You are AI CEO, a decisive, encouraging personal strategy coach.
A user set this goal: "${title}" (category: ${category}${targetDate ? `, target date: ${targetDate}` : ''}).

Break it into 5-8 concrete, sequential actions they can complete over the
coming weeks. Each action should be specific and doable in under an hour.
Respond ONLY as JSON: { "summary": string, "actions": [{ "description": string, "due_in_days": number }] }`

    const aiRes = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${OPENAI_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        response_format: { type: 'json_object' },
        messages: [{ role: 'user', content: prompt }]
      })
    })

    if (!aiRes.ok) throw new Error(`OpenAI error: ${aiRes.status}`)
    const aiJson = await aiRes.json()
    const parsed = JSON.parse(aiJson.choices[0].message.content)

    const { data: plan, error: planError } = await supabase
      .from('goal_plans')
      .insert({ goal_id: goalId, ai_summary: parsed.summary, raw_response: parsed })
      .select()
      .single()
    if (planError) throw planError

    const today = new Date()
    const actionRows = parsed.actions.map((a: { description: string; due_in_days: number }) => {
      const due = new Date(today)
      due.setDate(due.getDate() + (a.due_in_days ?? 3))
      return { goal_id: goalId, description: a.description, due_date: due.toISOString().slice(0, 10) }
    })

    const { error: actionsError } = await supabase.from('actions').insert(actionRows)
    if (actionsError) throw actionsError

    return new Response(JSON.stringify({ plan, actions: actionRows }), {
      headers: { 'Content-Type': 'application/json' }
    })
  } catch (err) {
    return new Response(JSON.stringify({ error: (err as Error).message }), {
      status: 400,
      headers: { 'Content-Type': 'application/json' }
    })
  }
})
