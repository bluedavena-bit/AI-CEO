-- AI CEO — v1 schema (Goals pillar)
-- Designed so Wealth, Credit, and Business can plug in later as more
-- `goals` with different categories, rather than separate tables/apps.
-- This is what lets the "shared AI context engine" work: one goals table,
-- one actions table, one AI, regardless of which pillar the goal belongs to.

create extension if not exists "uuid-ossp";

-- Supabase Auth already provides auth.users; we extend it with a profile.
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  stripe_customer_id text,
  subscription_status text default 'free' check (subscription_status in ('free', 'active', 'past_due', 'canceled')),
  created_at timestamptz default now()
);

create table public.goals (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  category text not null check (category in ('Wealth', 'Credit', 'Business', 'Health', 'Career', 'Personal')),
  target_date date,
  status text default 'active' check (status in ('active', 'completed', 'abandoned')),
  created_at timestamptz default now()
);

create table public.goal_plans (
  id uuid primary key default uuid_generate_v4(),
  goal_id uuid not null references public.goals(id) on delete cascade,
  ai_summary text,
  raw_response jsonb,
  created_at timestamptz default now()
);

create table public.actions (
  id uuid primary key default uuid_generate_v4(),
  goal_id uuid not null references public.goals(id) on delete cascade,
  description text not null,
  due_date date,
  completed_at timestamptz,
  created_at timestamptz default now()
);

create table public.checkins (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references auth.users(id) on delete cascade,
  goal_id uuid not null references public.goals(id) on delete cascade,
  reflection_text text,
  ai_response text,
  created_at timestamptz default now()
);

-- View that powers the dashboard in a single query instead of N+1 fetches.
create view public.goals_with_progress as
select
  g.*,
  count(a.id) filter (where a.id is not null) as total_actions,
  count(a.id) filter (where a.completed_at is not null) as completed_actions,
  coalesce(
    (select count(*) from (
      select distinct date_trunc('day', completed_at) as d
      from public.actions
      where goal_id = g.id and completed_at > now() - interval '30 days'
    ) streak_days), 0
  ) as streak
from public.goals g
left join public.actions a on a.goal_id = g.id
group by g.id;

-- Row-level security: every table is private to its owner by default.
-- This is the single most important line for an app handling financial
-- and personal goal data — it's also what an investor's security review
-- will check first.
alter table public.profiles enable row level security;
alter table public.goals enable row level security;
alter table public.goal_plans enable row level security;
alter table public.actions enable row level security;
alter table public.checkins enable row level security;

create policy "Users manage their own profile"
  on public.profiles for all
  using (auth.uid() = id);

create policy "Users manage their own goals"
  on public.goals for all
  using (auth.uid() = user_id);

create policy "Users read plans for their own goals"
  on public.goal_plans for select
  using (auth.uid() = (select user_id from public.goals where id = goal_id));

create policy "Users manage actions on their own goals"
  on public.actions for all
  using (auth.uid() = (select user_id from public.goals where id = goal_id));

create policy "Users manage their own checkins"
  on public.checkins for all
  using (auth.uid() = user_id);

-- Auto-create a profile row whenever someone signs up.
create function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id) values (new.id);
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();
